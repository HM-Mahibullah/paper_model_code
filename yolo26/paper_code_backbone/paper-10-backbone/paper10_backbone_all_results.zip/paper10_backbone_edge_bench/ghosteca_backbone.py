"""Paper 10 backbone for YOLO26n: C3k2 at layers 2, 4, 6, 8 -> C2f_GhostECA (GhostBottleneck + Enhanced ECA, k=7)."""
import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.block import C3k2
from ultralytics.nn.modules.conv import Conv, GhostConv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

GHOSTECA_LAYERS = (2, 4, 6, 8)


class EECA(nn.Module):
    """Enhanced ECA: global avg pool -> conv across channels (k=7) -> sigmoid -> scale. 1-D conv written as 4-D Conv2d."""

    def __init__(self, k=7):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv2d(1, 1, (k, 1), padding=(k // 2, 0), bias=False)
        self.act = nn.Sigmoid()

    def forward(self, x):
        y = self.pool(x).transpose(1, 2)  # (B, C, 1, 1) -> (B, 1, C, 1)
        y = self.act(self.conv(y)).transpose(1, 2)  # back to (B, C, 1, 1)
        return x * y


class GhostBottleneckECA(nn.Module):
    """GhostConv 3x3 -> GhostConv 3x3 -> EECA, with a residual connection."""

    def __init__(self, c, k=3):
        super().__init__()
        self.cv1 = GhostConv(c, c, k)
        self.cv2 = GhostConv(c, c, k)
        self.eca = EECA(7)

    def forward(self, x):
        return x + self.eca(self.cv2(self.cv1(x)))


class C2fGhostECA(nn.Module):
    """C2f with GhostBottleneck_ECA blocks: cv1 -> split -> n blocks -> concat all -> cv2."""

    def __init__(self, c1, c2, n=1, c=None):
        super().__init__()
        self.c = c or c2 // 2  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(GhostBottleneckECA(self.c) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))


def add_ghosteca(model, layers=GHOSTECA_LAYERS):
    """Replace C3k2 at the given layers with C2f_GhostECA, copying cv1 and cv2 (same shapes). Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, C3k2), f"layer {i} is {type(old).__name__}, not C3k2"
        new = C2fGhostECA(old.cv1.conv.in_channels, old.cv2.conv.out_channels, n=len(old.m), c=old.c)
        new.cv1.load_state_dict(old.cv1.state_dict())
        new.cv2.load_state_dict(old.cv2.state_dict())
        new = new.to(next(old.parameters()).device)
        new.i, new.f, new.type = old.i, old.f, "C2fGhostECA"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class GhostECATrainer(DetectionTrainer):
    """Loads the pretrained weights first, then swaps C3k2 -> C2f_GhostECA (cv1/cv2 keep the pretrained weights)."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_ghosteca(model)
        if RANK in {-1, 0}:
            print(f"Paper 10 backbone: C2f_GhostECA at layers {GHOSTECA_LAYERS}")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
