"""Paper 17 backbone for YOLO26n: ECA after the C3k2 at layer 6 (P4, k=3) and layer 8 (P5, k=5)."""
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.block import C3k2
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

ECA_LAYERS = {6: 3, 8: 5}  # layer index: ECA kernel size


class ECA(nn.Module):
    """Efficient Channel Attention: global avg pool -> conv across channels (kernel k) -> sigmoid -> scale. 1-D conv as 4-D Conv2d."""

    def __init__(self, k=3):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv2d(1, 1, (k, 1), padding=(k // 2, 0), bias=False)
        self.act = nn.Sigmoid()

    def forward(self, x):
        y = self.pool(x).transpose(1, 2)  # (B, C, 1, 1) -> (B, 1, C, 1)
        y = self.act(self.conv(y)).transpose(1, 2)  # back to (B, C, 1, 1)
        return x * y


class C3k2ECA(nn.Module):
    """A pretrained C3k2 block followed by ECA."""

    def __init__(self, block, k=3):
        super().__init__()
        self.block = block
        self.eca = ECA(k)

    def forward(self, x):
        return self.eca(self.block(x))


def add_eca(model, layers=ECA_LAYERS):
    """Wrap the C3k2 at the given layers with ECA (the C3k2 keeps its weights). Returns the model."""
    for i, k in layers.items():
        old = model.model[i]
        assert isinstance(old, C3k2), f"layer {i} is {type(old).__name__}, not C3k2"
        new = C3k2ECA(old, k).to(next(old.parameters()).device)
        new.i, new.f, new.type = old.i, old.f, "C3k2ECA"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class ECATrainer(DetectionTrainer):
    """Loads the pretrained weights first, then adds ECA after the C3k2 at layers 6 and 8."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_eca(model)
        if RANK in {-1, 0}:
            print(f"Paper 17 backbone: ECA after layers {list(ECA_LAYERS)} (k = {list(ECA_LAYERS.values())})")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
