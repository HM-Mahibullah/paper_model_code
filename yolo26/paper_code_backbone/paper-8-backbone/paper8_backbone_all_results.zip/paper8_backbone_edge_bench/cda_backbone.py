"""Paper 8 backbone for YOLO26n: C3k2 at layers 2, 4, 6, 8 -> CDA (C2f_DWS_Add); optional SPPF at layer 9 -> SimSPPF (ReLU)."""
from copy import deepcopy

import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.block import SPPF, C3k2
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

CDA_LAYERS = (2, 4, 6, 8)
SIMSPPF_LAYER = 9


class DWS(nn.Module):
    """Depthwise separable convolution: depthwise 3x3 + pointwise 1x1, each with BN + SiLU."""

    def __init__(self, c):
        super().__init__()
        self.dw = Conv(c, c, 3, 1, g=c)
        self.pw = Conv(c, c, 1, 1)

    def forward(self, x):
        return self.pw(self.dw(x))


class CDA(nn.Module):
    """C2f_DWS_Add: split into x1, x2; x2 = DWS(x2) + x2 (n times); concat [x1, x2]; 1x1 conv."""

    def __init__(self, c1, c2, n=1, c=None):
        super().__init__()
        self.c = c or c2 // 2  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.m = nn.ModuleList(DWS(self.c) for _ in range(n))
        self.cv2 = Conv(2 * self.c, c2, 1, 1)

    def forward(self, x):
        x1, x2 = self.cv1(x).chunk(2, 1)
        for m in self.m:
            x2 = m(x2) + x2
        return self.cv2(torch.cat((x1, x2), 1))


class SimSPPF(SPPF):
    """SPPF with ReLU activations (YOLOv6 SimSPPF). Same weights and forward as SPPF."""


def _swap(model, i, new, name):
    old = model.model[i]
    new = new.to(next(old.parameters()).device)
    new.i, new.f, new.type = old.i, old.f, name  # keep the routing attributes used by the model's forward
    new.np = sum(p.numel() for p in new.parameters())
    model.model[i] = new


def add_cda(model, layers=CDA_LAYERS):
    """Replace C3k2 at the given layers with CDA, copying cv1 and the matching part of cv2. Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, C3k2), f"layer {i} is {type(old).__name__}, not C3k2"
        c, n = old.c, len(old.m)
        new = CDA(old.cv1.conv.in_channels, old.cv2.conv.out_channels, n=n, c=c)
        new.cv1.load_state_dict(old.cv1.state_dict())
        with torch.no_grad():  # base cv2 reads [x1, x2, y1..yn]; CDA cv2 reads [x1, x2]
            new.cv2.conv.weight.copy_(old.cv2.conv.weight[:, : 2 * c])
        new.cv2.bn.load_state_dict(old.cv2.bn.state_dict())
        _swap(model, i, new, "CDA")
    return model


def add_simsppf(model, layer=SIMSPPF_LAYER):
    """Turn the SPPF at the given layer into SimSPPF (all weights kept, activations -> ReLU). Returns the model."""
    old = model.model[layer]
    assert type(old) is SPPF, f"layer {layer} is {type(old).__name__}, not SPPF"
    new = deepcopy(old)
    new.__class__ = SimSPPF
    new.cv1.act = nn.ReLU()
    new.cv2.act = nn.ReLU()
    _swap(model, layer, new, "SimSPPF")
    return model


class CDATrainer(DetectionTrainer):
    """Loads the pretrained weights first, then swaps C3k2 -> CDA (and SPPF -> SimSPPF when SIMSPPF is True)."""

    SIMSPPF = False

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_cda(model)
        if self.SIMSPPF:
            add_simsppf(model)
        if RANK in {-1, 0}:
            print(f"Paper 8 backbone: CDA at layers {CDA_LAYERS}" + (f", SimSPPF at layer {SIMSPPF_LAYER}" if self.SIMSPPF else ""))
        if verbose and RANK in {-1, 0}:
            model.info()
        return model


class CDASimSPPFTrainer(CDATrainer):
    SIMSPPF = True
