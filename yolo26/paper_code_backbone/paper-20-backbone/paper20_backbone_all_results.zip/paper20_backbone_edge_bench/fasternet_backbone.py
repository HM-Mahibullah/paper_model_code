"""Paper 20 backbone for YOLO26n: FasterNet blocks inside the C3k2 at layers 6 and 8; optional SimSPPF (ReLU) at layer 9."""
from copy import deepcopy

import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.block import SPPF, C3k2
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

FASTER_LAYERS = (6, 8)
SIMSPPF_LAYER = 9


class PConv(nn.Module):
    """Partial convolution: 3x3 conv on the first dim // n_div channels, the rest pass through unchanged."""

    def __init__(self, dim, n_div=4):
        super().__init__()
        self.dc = dim // n_div
        self.du = dim - self.dc
        self.conv = nn.Conv2d(self.dc, self.dc, 3, 1, 1, bias=False)

    def forward(self, x):
        x1, x2 = torch.split(x, [self.dc, self.du], 1)
        return torch.cat((self.conv(x1), x2), 1)


class FasterBlock(nn.Module):
    """FasterNet block: x + 1x1(1x1+BN+SiLU(PConv(x))). The last 1x1 conv starts at zero, so the block starts as identity."""

    def __init__(self, dim, n_div=4, mlp_ratio=2):
        super().__init__()
        self.pconv = PConv(dim, n_div)
        self.mlp = nn.Sequential(Conv(dim, dim * mlp_ratio, 1), nn.Conv2d(dim * mlp_ratio, dim, 1, bias=False))
        nn.init.zeros_(self.mlp[-1].weight)

    def forward(self, x):
        return x + self.mlp(self.pconv(x))


class SimSPPF(SPPF):
    """SPPF with ReLU activations (YOLOv6 SimSPPF). Same weights and forward as SPPF."""


def add_faster(model, layers=FASTER_LAYERS):
    """Replace the inner block(s) of the C3k2 at the given layers with FasterNet blocks; cv1/cv2 keep their weights."""
    for i in layers:
        m = model.model[i]
        assert isinstance(m, C3k2), f"layer {i} is {type(m).__name__}, not C3k2"
        dev = next(m.parameters()).device
        m.m = nn.ModuleList(FasterBlock(m.c) for _ in range(len(m.m))).to(dev)
        m.type = "C3k2_Faster"
        m.np = sum(p.numel() for p in m.parameters())
    return model


def add_simsppf(model, layer=SIMSPPF_LAYER):
    """Turn the SPPF at the given layer into SimSPPF (all weights kept, activations -> ReLU). Returns the model."""
    old = model.model[layer]
    assert type(old) is SPPF, f"layer {layer} is {type(old).__name__}, not SPPF"
    new = deepcopy(old)
    new.__class__ = SimSPPF
    new.cv1.act = nn.ReLU()
    new.cv2.act = nn.ReLU()
    new.type = "SimSPPF"
    model.model[layer] = new
    return model


class FasterTrainer(DetectionTrainer):
    """Loads the pretrained weights first, then FasterNet blocks at layers 6 and 8 (and SimSPPF at layer 9 when SIMSPPF is True)."""

    SIMSPPF = False

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_faster(model)
        if self.SIMSPPF:
            add_simsppf(model)
        if RANK in {-1, 0}:
            print(f"Paper 20 backbone: FasterNet blocks at layers {FASTER_LAYERS}" + (f", SimSPPF at layer {SIMSPPF_LAYER}" if self.SIMSPPF else ""))
        if verbose and RANK in {-1, 0}:
            model.info()
        return model


class FasterSimSPPFTrainer(FasterTrainer):
    SIMSPPF = True
