"""Paper 14 backbone for YOLO26n: stride-2 Conv at layers 3, 5, 7 -> FWAMSConv (1x1 reduce, DW 3/5/7 s2, concat, 1x1 + BN + ReLU)."""
import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

FWAMS_LAYERS = (3, 5, 7)


class FWAMSConv(nn.Module):
    """Forest Wildfire Adaptive Multi-Scale Conv: 1x1 reduce -> depthwise 3x3/5x5/7x7 (stride s) -> concat -> 1x1 + BN + ReLU."""

    def __init__(self, c1, c2, s=2, factor=2):
        super().__init__()
        c_ = c1 // factor
        self.reduce = Conv(c1, c_, 1, 1)
        self.dw3 = Conv(c_, c_, 3, s, g=c_)
        self.dw5 = Conv(c_, c_, 5, s, g=c_)
        self.dw7 = Conv(c_, c_, 7, s, g=c_)
        self.pw = Conv(3 * c_, c2, 1, 1, act=nn.ReLU())

    def forward(self, x):
        x = self.reduce(x)
        return self.pw(torch.cat((self.dw3(x), self.dw5(x), self.dw7(x)), 1))


def add_fwams(model, layers=FWAMS_LAYERS):
    """Replace the stride-2 Conv at the given backbone layers with FWAMSConv (same in/out channels). Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, Conv) and old.conv.kernel_size == (3, 3) and old.conv.stride == (2, 2), f"layer {i} is not a 3x3 s2 Conv"
        new = FWAMSConv(old.conv.in_channels, old.conv.out_channels, s=2)
        new = new.to(next(old.parameters()).device)
        new.i, new.f, new.type = old.i, old.f, "FWAMSConv"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class FWAMSTrainer(DetectionTrainer):
    """DetectionTrainer that inserts FWAMSConv, then loads the pretrained weights (FWAMSConv layers start from scratch)."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        add_fwams(model)
        if weights:
            model.load(weights)
        if RANK in {-1, 0}:
            print(f"Paper 14 backbone: FWAMSConv at layers {FWAMS_LAYERS}")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
