"""Paper 2 backbone for YOLO26n: stride-2 Conv at layers 3, 5, 7 -> DSConv (depthwise 3x3 s2 + pointwise 1x1)."""
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

DSCONV_LAYERS = (3, 5, 7)


class DSConv(nn.Module):
    """Depthwise separable convolution: depthwise kxk (stride s) + pointwise 1x1, each with BN + SiLU."""

    def __init__(self, c1, c2, k=3, s=2):
        super().__init__()
        self.dw = Conv(c1, c1, k, s, g=c1)
        self.pw = Conv(c1, c2, 1, 1)

    def forward(self, x):
        return self.pw(self.dw(x))


def add_dsconv(model, layers=DSCONV_LAYERS):
    """Replace the stride-2 Conv at the given backbone layers with DSConv (same in/out channels). Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, Conv) and old.conv.kernel_size == (3, 3) and old.conv.stride == (2, 2), f"layer {i} is not a 3x3 s2 Conv"
        new = DSConv(old.conv.in_channels, old.conv.out_channels, 3, 2)
        new.i, new.f, new.type = old.i, old.f, "DSConv"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class DSConvTrainer(DetectionTrainer):
    """DetectionTrainer that inserts DSConv, then loads the pretrained weights (DSConv layers start from scratch)."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        add_dsconv(model)
        if weights:
            model.load(weights)
        if RANK in {-1, 0}:
            print(f"Paper 2 backbone: DSConv at layers {DSCONV_LAYERS}")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
