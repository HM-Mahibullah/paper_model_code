"""Paper 21 backbone for YOLO26n: stride-2 Conv at layer 3 -> SPDConv (space-to-depth + 3x3 stride-1 Conv), exact warm start."""
import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

SPD_LAYERS = (3,)

# space-to-depth sub-images in channel order: (row offset a, column offset b)
SUBS = ((0, 0), (1, 0), (0, 1), (1, 1))
# tap of a 3x3 stride-2 kernel (dy = -1, 0, +1) -> (sub-image offset, tap of the new 3x3 stride-1 kernel)
TAP = {0: (1, 0), 1: (0, 1), 2: (1, 1)}


class SPDConv(nn.Module):
    """Space-to-depth (2x2 -> channels) followed by a 3x3 stride-1 Conv (BN + SiLU)."""

    def __init__(self, c1, c2):
        super().__init__()
        self.conv = Conv(4 * c1, c2, 3, 1)

    def forward(self, x):
        x = torch.cat([x[..., a::2, b::2] for a, b in SUBS], 1)
        return self.conv(x)


@torch.no_grad()
def init_from_strided(spd, old):
    """Set the SPDConv weights so that it reproduces the pretrained 3x3 stride-2 Conv exactly; copy its BatchNorm."""
    c1 = old.conv.in_channels
    w_old = old.conv.weight
    w_new = torch.zeros_like(spd.conv.conv.weight)
    for ky, (a, ny) in TAP.items():
        for kx, (b, nx) in TAP.items():
            s = SUBS.index((a, b))
            w_new[:, s * c1:(s + 1) * c1, ny, nx] += w_old[:, :, ky, kx]
    spd.conv.conv.weight.copy_(w_new)
    spd.conv.bn.load_state_dict(old.bn.state_dict())


def add_spd(model, layers=SPD_LAYERS):
    """Replace the stride-2 Conv at the given backbone layers with SPDConv (exact warm start). Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, Conv) and old.conv.kernel_size == (3, 3) and old.conv.stride == (2, 2), f"layer {i} is not a 3x3 s2 Conv"
        assert old.conv.padding == (1, 1) and old.conv.groups == 1 and old.conv.dilation == (1, 1)
        new = SPDConv(old.conv.in_channels, old.conv.out_channels).to(old.conv.weight.device)
        init_from_strided(new, old)
        new.i, new.f, new.type = old.i, old.f, "SPDConv"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class SPDTrainer(DetectionTrainer):
    """Loads the pretrained weights first, then swaps layer 3 for SPDConv initialised from the pretrained conv."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_spd(model)
        if RANK in {-1, 0}:
            print(f"Paper 21 backbone: SPDConv at layers {SPD_LAYERS}")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
