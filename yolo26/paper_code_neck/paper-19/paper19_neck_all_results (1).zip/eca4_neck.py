"""Paper 19 (GECA-YOLOv26) neck for YOLO26n: ECA (k=5) after each neck Concat (layers 12, 15, 18, 21), i.e. between Concat and C3k2.
Backbone = proposed ADown (3, 5, 7) + ECA (6, 8)."""
import torch
import torch.nn as nn

from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.nn.modules.conv import Concat
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import RANK

from eca_backbone import ECA, ECA_LAYERS, add_eca

NECK_ECA_LAYERS = (12, 15, 18, 21)
NECK_ECA_K = 5


class ConcatECA(nn.Module):
    """Concat followed by ECA."""

    def __init__(self, d=1, k=NECK_ECA_K):
        super().__init__()
        self.d = d
        self.eca = ECA(k)

    def forward(self, x):
        return self.eca(torch.cat(x, self.d))


def add_neck_eca(model, layers=NECK_ECA_LAYERS, k=NECK_ECA_K):
    """Attach ECA to the Concat at the given neck layers. Returns the model."""
    for i in layers:
        old = model.model[i]
        assert isinstance(old, Concat), f"layer {i} is {type(old).__name__}, not Concat"
        new = ConcatECA(old.d, k).to(next(model.parameters()).device)
        new.i, new.f, new.type = old.i, old.f, "ConcatECA"  # keep the routing attributes used by the model's forward
        new.np = sum(p.numel() for p in new.parameters())
        model.model[i] = new
    return model


class ECA4NeckTrainer(DetectionTrainer):
    """Builds the ADown YAML, loads the pretrained weights, adds ECA (layers 6, 8), then ECA after the neck Concat layers."""

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=self.data["channels"], verbose=False)
        if weights:
            model.load(weights)
        add_eca(model)
        add_neck_eca(model)
        if RANK in {-1, 0}:
            print(f"Backbone: ADown 3, 5, 7 + ECA after {list(ECA_LAYERS)} | Neck (Paper 19): ECA (k={NECK_ECA_K}) after Concat {NECK_ECA_LAYERS}")
        if verbose and RANK in {-1, 0}:
            model.info()
        return model
